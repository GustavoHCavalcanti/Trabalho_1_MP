#ifndef VELHA_HPP
#define VELHA_HPP

class JogoDaVelha {
public:
    int verificar_jogo(int matriz[3][3]);
};

#endif // VELHA_HPP
